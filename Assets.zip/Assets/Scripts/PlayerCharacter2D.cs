﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerCharacter2D : MonoBehaviour
{
    public int Speed;
    public SpriteRenderer sr;
    public Animator anim;
    public float JumpForce;
    public Rigidbody2D rig;
    bool IsGrounded;
    float ShootTimer = 0.2f;
    bool ShotTimer;

    public Transform positionLeft;
    public Transform positionRight;
    public GameObject bullet;

    public float ShotSpeed;
    public int hp = 3;
    public Transform SpawnPoint;

    // Start is called before the first frame update
    void Start()
    {
        IsGrounded = true;
        ShotTimer = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(hp <= 0)
        {
            Destroy(gameObject);
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }

        if(transform.position.y < -10)
        {
            hp--;
            if (hp != 0)
            {
                transform.position = SpawnPoint.position;
            }
        }

        if (ShotTimer)
        {
            ShootTimer -= Time.deltaTime;
        }
        if(ShootTimer<=0)
        {
            ShotTimer = false;
            anim.SetBool("IsShooting", false);
            ShootTimer = .2f;
        }
        Movement();
        if (IsGrounded) anim.SetBool("IsGrounded", true);
        else anim.SetBool("IsGrounded", false);
        if(rig.velocity.y < 0)
        {
            rig.velocity += Vector2.up * Physics2D.gravity.y * 2 * Time.deltaTime;
        }
    }

    void Movement()
    {
        if(Input.GetMouseButton(0))
        {
            if (!ShotTimer)
            {
                if (!sr.flipX)
                {
                    GameObject newBullet = Instantiate(bullet, positionLeft.position, transform.rotation);
                    newBullet.GetComponent<Rigidbody2D>().velocity = Vector2.right * -ShotSpeed;

                }
                else
                {
                    GameObject newBullet = Instantiate(bullet, positionRight.position, transform.rotation);
                    newBullet.GetComponent<Rigidbody2D>().velocity = Vector2.right * ShotSpeed;
                }

                anim.SetBool("IsShooting", true);
                ShotTimer = true;
            }
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (IsGrounded)
            {
                rig.AddForce(Vector2.up * JumpForce);
                anim.SetBool("IsShooting", false);
                IsGrounded = false;
            }

        }

        if (Input.GetKey(KeyCode.D))
        {
            anim.SetBool("isWalking", true);
            anim.SetBool("IsShooting", false);

            transform.Translate (new Vector3(Speed*Time.deltaTime,0,0));
            sr.flipX = true;
        }

        else if (Input.GetKey(KeyCode.A))
        {
            anim.SetBool("isWalking", true);
            anim.SetBool("IsShooting", false);

            transform.Translate(new Vector3(-Speed * Time.deltaTime, 0, 0));
            sr.flipX = false;
        }

        else anim.SetBool("isWalking", false);
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if(col.gameObject.tag == "Ground")
        {
            IsGrounded = true;
        }

        if(col.gameObject.tag == "Enemy")
        {
            hp--;
            if (hp != 0)
            {
                transform.position = SpawnPoint.position;
            }
        }
        if(col.gameObject.tag == "Bullet")
        {
            Destroy(col.gameObject);
        }
    }
}
