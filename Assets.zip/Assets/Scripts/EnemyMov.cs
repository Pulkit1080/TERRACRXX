﻿using UnityEngine;

public class EnemyMov : MonoBehaviour
{
    int hp = 3;
    Rigidbody2D myBody;
    Transform myTrans;
    float myWidth;
    public float speed;
    public GameObject Particle;

    private void Start()
    {

        myBody = this.GetComponent<Rigidbody2D>();
        myTrans = this.transform;
        myWidth = GetComponent<SpriteRenderer>().bounds.extents.x;
    }

    private void FixedUpdate()
    {
        if (hp <= 0)
        {
            Destroy(gameObject);
        }
        Vector2 lineCastPos = myTrans.position - myTrans.right * myWidth;
        bool isGrounded = Physics2D.Linecast(lineCastPos, lineCastPos + Vector2.down);

        if(!isGrounded)
        {
            Vector3 currRot = myTrans.eulerAngles;
            currRot.y += 180;
            myTrans.eulerAngles = currRot;
        }
        Vector3 myVel = myBody.velocity;
        myVel.x = -myTrans.right.x * speed;
        myBody.velocity = myVel;

    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if(col.gameObject.tag == "Bullet")
        {
            hp --;
            Destroy(col.gameObject);
            Instantiate(Particle, transform.position, transform.rotation);
        }
    }
}
