﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Play : MonoBehaviour
{
       public void play()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
